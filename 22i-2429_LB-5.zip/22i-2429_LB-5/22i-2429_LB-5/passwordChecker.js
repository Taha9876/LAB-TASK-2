const checkPassword = (password) => {
  const checks = {
    length: password.length >= 8,
    uppercase: /[A-Z]/.test(password),
    lowercase: /[a-z]/.test(password),
    number: /[0-9]/.test(password),
    special: /[@#$%]/.test(password)
  };

  const passedChecks = Object.values(checks).filter(check => check).length;

  if (passedChecks >= 5) {
    return "Strong";
  } else if (passedChecks >= 3) {
    return "Medium";
  } else {
    return "Weak";
  }
};

const passwords = [
  "abc123",
  "Password1",
  "Pass@123",
  "weak",
  "STRONG@PASSWORD123",
  "NoSpecial123",
  "pass@123"
];

passwords.forEach(pwd => {
  const strength = checkPassword(pwd);
  console.log(`Password: "${pwd}" → Strength: ${strength}`);
});
