const movies = [];

const addMovie = (title, director, genre, year) => {
  movies.push({ title, director, genre, year });
};

const listMovies = () => {
  const formatted = movies.map(movie => 
    `${movie.title} (${movie.year}) - Director: ${movie.director}, Genre: ${movie.genre}`
  ).join("\n");
  console.log(formatted);
};

const searchByDirector = (director) => {
  return movies.filter(movie => 
    movie.director.toLowerCase() === director.toLowerCase()
  );
};

const searchByGenre = (genre) => {
  return movies.filter(movie => 
    movie.genre.toLowerCase() === genre.toLowerCase()
  );
};

addMovie("Inception", "Christopher Nolan", "Sci-Fi", 2010);
addMovie("The Dark Knight", "Christopher Nolan", "Action", 2008);
addMovie("Interstellar", "Christopher Nolan", "Sci-Fi", 2014);
addMovie("Pulp Fiction", "Quentin Tarantino", "Crime", 1994);
addMovie("Kill Bill", "Quentin Tarantino", "Action", 2003);

console.log("All Movies:");
listMovies();

console.log("\nMovies by Christopher Nolan:");
console.log(searchByDirector("christopher nolan"));

console.log("\nSci-Fi Movies:");
console.log(searchByGenre("sci-fi"));

console.log("\nMovies by Quentin Tarantino:");
console.log(searchByDirector("QUENTIN TARANTINO"));
