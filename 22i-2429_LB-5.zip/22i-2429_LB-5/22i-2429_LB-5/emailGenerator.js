const getInitials = (department) => {
  return department.split(" ").map(word => word.charAt(0).toLowerCase()).join("");
};

const generateEmail = (fullName, department) => {
  const nameParts = fullName.trim().split(/\s+/);
  const firstName = nameParts[0].toLowerCase();
  const lastName = nameParts[nameParts.length - 1].toLowerCase();
  const initials = getInitials(department);
  
  return `${firstName}.${lastName}@${initials}.uni.edu`;
};

const testCases = [
  { name: "Muhammad Ali Khan", department: "Software Engineering" },
  { name: "Fatima Ahmed", department: "Computer Science" },
  { name: "Hassan Khan", department: "Information Technology" },
  { name: "Sara Ahmed Khan", department: "Business Administration" }
];

testCases.forEach(test => {
  const email = generateEmail(test.name, test.department);
  console.log(`Name: ${test.name}`);
  console.log(`Department: ${test.department}`);
  console.log(`Email: ${email}`);
  console.log();
});
