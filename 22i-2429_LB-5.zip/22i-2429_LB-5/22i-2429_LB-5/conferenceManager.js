const attendees = [];
const MAX_CAPACITY = 100;

const addAttendee = (name, email, ticketType) => {
  if (attendees.length < MAX_CAPACITY) {
    attendees.push({ name, email, ticketType });
    return true;
  }
  return false;
};

const isFull = () => {
  return attendees.length >= MAX_CAPACITY;
};

const listAttendees = () => {
  console.log("Conference Attendees:");
  attendees.forEach((attendee, index) => {
    console.log(`${index + 1}. ${attendee.name} (${attendee.email}) - ${attendee.ticketType}`);
  });
};

const countByTicketType = (type) => {
  return attendees.filter(attendee => attendee.ticketType === type).length;
};

addAttendee("Ahmed Ali", "ahmed@email.com", "VIP");
addAttendee("Fatima Khan", "fatima@email.com", "General");
addAttendee("Hassan Khan", "hassan@email.com", "Speaker");
addAttendee("Sara Ahmed", "sara@email.com", "VIP");

console.log("Total attendees:", attendees.length);
console.log("Conference full?", isFull());
listAttendees();
console.log("VIP tickets:", countByTicketType("VIP"));
console.log("General tickets:", countByTicketType("General"));
console.log("Speaker tickets:", countByTicketType("Speaker"));
