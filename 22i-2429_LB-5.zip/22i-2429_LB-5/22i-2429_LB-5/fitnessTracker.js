const steps = [4500, 6200, 5800, 7100, 4900, 8300, 6700];

const addSteps = (dayIndex, stepsCount) => {
  if (dayIndex >= 0 && dayIndex < steps.length) {
    steps[dayIndex] = stepsCount;
  }
};

const getHighestSteps = () => {
  return Math.max(...steps);
};

const getLowestSteps = () => {
  return Math.min(...steps);
};

const getAverageSteps = () => {
  return steps.reduce((sum, count) => sum + count, 0) / steps.length;
};

const getAboveAverageDays = () => {
  const avg = getAverageSteps();
  return steps.filter(count => count > avg);
};

console.log("Initial steps:", steps);
console.log("Highest:", getHighestSteps());
console.log("Lowest:", getLowestSteps());
console.log("Average:", getAverageSteps());
console.log("Above average days:", getAboveAverageDays());

addSteps(0, 5500);
console.log("After update:", steps);
