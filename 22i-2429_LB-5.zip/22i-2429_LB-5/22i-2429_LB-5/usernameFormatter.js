
const cleanUsername = (name) => {
  return name.trim().toLowerCase().replace(/\s+/g, "_");
};

const validateUsername = (name) => {
  const cleaned = cleanUsername(name);
  
  if (cleaned.length < 5 || cleaned.length > 20) {
    return false;
  }
  
  if (!/^[a-z]/.test(cleaned)) {
    return false;
  }
  
  if (!/^[a-z0-9_]+$/.test(cleaned)) {
    return false;
  }
  
  return true;
};

const testUsernames = [
  " AHMAD_kHan123 ",
  " john doe ",
  "a123",
  "valid_user_2024",
  "123invalid",
  "invalid@user",
  " SARAH   AHMED   45 "
];

testUsernames.forEach(username => {
  const cleaned = cleanUsername(username);
  const isValid = validateUsername(username);
  console.log(`Input: "${username}" → Cleaned: "${cleaned}" → Valid: ${isValid}`);
});
