const countWords = (message) => {
  return message.trim().split(/\s+/).length;
};

const countCharacters = (message) => {
  return message.length;
};

const containsUrgent = (message) => {
  const urgentKeywords = ["urgent", "asap", "immediately", "important"];
  const lowerMessage = message.toLowerCase();
  return urgentKeywords.some(keyword => lowerMessage.includes(keyword));
};

const isShouting = (message) => {
  const letters = message.match(/[a-zA-Z]/g) || [];
  if (letters.length === 0) return false;
  
  const uppercase = message.match(/[A-Z]/g) || [];
  const percentage = (uppercase.length / letters.length) * 100;
  
  return percentage > 70;
};

const analyzeMessage = (message) => {
  return {
    words: countWords(message),
    characters: countCharacters(message),
    hasUrgent: containsUrgent(message),
    isShouting: isShouting(message)
  };
};

const messages = [
  "Sir I submitted the Assignment today!!!",
  "This is URGENT and needs immediate attention ASAP",
  "hello world",
  "PLEASE HELP ME NOW"
];

messages.forEach(msg => {
  console.log(`Message: "${msg}"`);
  console.log(analyzeMessage(msg));
  console.log();
});
