console.log("=== Task A: Fixed ===");
const getAverage = (arr) => {
  let sum = 0;
  arr.forEach(num => sum += num);
  return sum / arr.length;
};
console.log("Average of [10,20,30]:", getAverage([10, 20, 30]));

console.log("\n=== Task B: Fixed ===");
const findLongestWord = (str) => {
  let words = str.split(" ");
  return words.reduce((a, b) => {
    return a.length > b.length ? a : b;
  });
};
console.log("Longest word:", findLongestWord("JavaScript is very powerful language"));

console.log("\n=== Task C: Fixed ===");
const checkPass = (marks) => {
  return marks.every(m => m >= 50) ? "Pass" : "Fail";
};
console.log("Check [20,30,40]:", checkPass([20, 30, 40]));
console.log("Check [50,60,70]:", checkPass([50, 60, 70]));
